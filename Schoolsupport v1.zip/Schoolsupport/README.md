Hey, make sure you have the jfreechart jar added too this project, version 1.5.5
and above please.